alias onauto="bash ~/RIOBETA1/scripts/onauto"
alias offauto="bash ~/RIOBETA1/scripts/offauto"

# =========================
# 🚀 ONAUTO COMPLETO (DOWNLOAD → GIT → RAILWAY)
# =========================

alias onauto='
echo "🚀 ONAUTO ATIVADO (MONITORAMENTO + DEPLOY + RAILWAY)"

while true; do
  for file in ~/storage/downloads/*.zip; do
    [ -e "$file" ] || continue

    echo "📦 ZIP detectado: $file"

    # Extrair ZIP
    unzip -o "$file" -d ~/RIOBETA1 >/dev/null 2>&1

    cd ~/RIOBETA1 || exit

    # Commit principal
    git add -A
    git commit -m "auto update $(date)" >/dev/null 2>&1
    git push origin main --force >/dev/null 2>&1

    echo "🚂 Acionando Railway..."

    # Forçar novo deploy Railway (sem alterar estrutura)

    git push origin main --force >/dev/null 2>&1

    # Limpar ZIP
    rm -f "$file"

    echo "✅ Deploy completo (GitHub + Railway)"
  done

  sleep 5
done
'

# =========================
# 🛑 DESLIGAR ONAUTO
# =========================

alias offauto='
echo "🛑 ONAUTO DESATIVADO"
pkill -f onauto
'

export PATH="$HOME/bin:$PATH"
alias riopush="rio-sync"
alias rion="rio-auto-on"
alias riooff="rio-auto-off"
alias riolog="rio-log"
export PATH=$HOME/bin:$PATH
export PATH=$HOME/bin:$PATH
